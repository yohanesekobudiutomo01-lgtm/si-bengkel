<?php
    include("sess_check.php");

    // 1. Tangkap ID transaksi (bisa dari URL via GET saat tombol hapus diklik, atau dari form POST saat konfirmasi)
    $id_trx = isset($_GET['id']) ? $_GET['id'] : (isset($_POST['id_trx']) ? $_POST['id_trx'] : '');

    if(empty($id_trx)) {
        echo "<script>window.location='trx.php';</script>";
        exit();
    }

    // 2. Jika form password admin disubmit
    if(isset($_POST['proses_hapus'])) {
        $input_password = $_POST['pass_adm'];
        
        // Cek password ke tabel admin
        $q_admin = mysqli_query($conn, "SELECT * FROM admin");
        $password_benar = false;
        
        while($d_admin = mysqli_fetch_array($q_admin)) {
            if($input_password == $d_admin['pass_adm'] || md5($input_password) == $d_admin['pass_adm']) {
                $password_benar = true;
                break;
            }
        }

        if($password_benar) {
            // A. Kembalikan stok barang
            $sql = "SELECT tmp_trx.*, barangjasa.* FROM tmp_trx, barangjasa WHERE tmp_trx.id_brg=barangjasa.id_brg AND tmp_trx.id_trx='$id_trx'";
            $query = mysqli_query($conn, $sql);
            
            while($res = mysqli_fetch_array($query)){
                if($res['jenis'] == 'barang'){
                    $newst = $res['stok'] + $res['jml'];
                    mysqli_query($conn, "UPDATE barangjasa SET stok='$newst' WHERE id_brg='".$res['id_brg']."'");  
                }
            }

            // B. Hapus data transaksi utama dan data sementara
            mysqli_query($conn, "DELETE FROM trx WHERE id_trx='$id_trx'");
            mysqli_query($conn, "DELETE FROM tmp_trx WHERE id_trx='$id_trx'");

            echo "<script>alert('Transaksi berhasil dihapus dan stok dikembalikan!'); window.location='trx.php';</script>";
            exit();
        } else {
            echo "<script>alert('Password Admin Salah!');</script>";
        }
    }

    // 3. Jika belum submit password, tampilkan Tampilan Form Halaman Otorisasi
    $pagedesc = "Otorisasi Admin";
    include("layout_top.php");
?>
<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Otorisasi Hapus Transaksi</h1>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Masukkan Password Admin untuk Menghapus Transaksi: <b><?php echo $id_trx; ?></b>
                    </div>
                    <div class="panel-body">
                        <form action="trx_hapus.php" method="POST">
                            <!-- Kirim ID Transaksi lewat hidden input -->
                            <input type="hidden" name="id_trx" value="<?php echo $id_trx; ?>">
                            
                            <div class="form-group">
                                <label>Password Admin</label>
                                <input type="password" name="pass_adm" class="form-control" placeholder="Masukkan password admin..." required autofocus>
                            </div>
                            <button type="submit" name="proses_hapus" class="btn btn-danger">Konfirmasi Hapus</button>
                            <a href="trx.php" class="btn btn-default">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    include("layout_bottom.php");
?>